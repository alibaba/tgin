package com.alibaba.aliyun.mapred.graph.triangle2.triangle;


import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.IntStream;


public class Dpp {

    public static String[] run(int topK, String[] itemIds, float[] u2iScore, List<Set<String>> itemKeywordSet) {
        float[][] i2iSimilar = getI2ISimilarMatrix(itemKeywordSet);
        float[][] kernelMatrix = getKernalMatrix(u2iScore, i2iSimilar);
        float epsilon = 1e-9F;
        return getTopItem(kernelMatrix, itemIds, topK, epsilon);
    }

    public static float[][] getI2ISimilarMatrix(List<Set<String>> keywords) {
        if (keywords == null || keywords.size() < 1) {
            return null;
        }
        int row = keywords.size();
        int column = keywords.size();
        float[][] result = new float[row][column];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                Set<String> s1 = keywords.get(i);
                Set<String> s2 = keywords.get(j);
                Set<String> union = new HashSet<>();
                union.addAll(s1);
                union.addAll(s2);
                int flag = 0;
                for (String key : union) {
                    if (s1.contains(key) && s2.contains(key)){
                        flag++;
                    }
                }
                result[i][j] = (float) (1.0*flag / union.size());
            }
        }
        return result;
    }

    private static float[][] getKernalMatrix(float[] u2iScore, float[][] i2iSimilar) {
        int row = i2iSimilar.length;
        int column = i2iSimilar.length;
        float[][] result = new float[row][column];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                result[i][j] = u2iScore[i] * i2iSimilar[i][j] * u2iScore[j];
            }
        }
        return result;
    }

    private static String[] getTopItem(float[][] kernelMatrix, String[] itemIds, int topK, float epsilon) {
        int itemIdNum = kernelMatrix.length;
        float[][] cis = new float[topK][itemIdNum];
        float[] di2s = getDi2s(kernelMatrix);
        String[] topItemIds = new String[topK];
        int maxValueItemIndex = getMaxValueArrayIndex(di2s);
        topItemIds[0] = itemIds[maxValueItemIndex];
        float[] eis = new float[itemIdNum];
        int index = 1;
        while (index < topK) {
            int k = index - 1;
            float[] ciOptimal = getCiOpt(k, maxValueItemIndex, cis);
            float diOptimal = (float) Math.sqrt(di2s[maxValueItemIndex]);

            float[] elements = getElements(maxValueItemIndex, kernelMatrix);
            calEis(itemIdNum, k, ciOptimal, cis, elements, diOptimal, eis);
            updateCis(k, itemIdNum, cis, eis);
            updateDi2s(itemIdNum, di2s, eis);

            maxValueItemIndex = getMaxValueArrayIndex(di2s);
            if (di2s[maxValueItemIndex] < epsilon) {
                break;
            }
            topItemIds[index] = itemIds[maxValueItemIndex];
            index++;
        }
        return topItemIds;
    }

    private static float[] getDi2s(float[][] kernelMatrix) {
        int row = kernelMatrix.length;
        float[] result = new float[row];
        for (int i = 0; i < row; i++) {
            result[i] = kernelMatrix[i][i];
        }
        return result;
    }

    private static int getMaxValueArrayIndex(float[] array) {
        return IntStream.range(0, array.length).reduce((i, j) -> array[i] > array[j] ? i : j).getAsInt();
    }

    private static float[] getCiOpt(int k, int maxValueItemIndex, float[][] cis) {
        float[] result = new float[k];
        for (int i = 0; i < k; i++) {
            result[i] = cis[i][maxValueItemIndex];
        }
        return result;
    }

    private static float[] getElements(int maxValueItemIndex, float[][] kernelMatrix) {
        int length = kernelMatrix.length;
        float[] result = new float[length];
        System.arraycopy(kernelMatrix[maxValueItemIndex], 0, result, 0, length);
        return result;
    }

    private static void calEis(int itemIdNum, int k, float[] ciOptimal, float[][] cis, float[] elements, float diOptimal, float[] eis) {
        for (int i = 0; i < itemIdNum; i++) {
            float rt = 0;
            for (int j = 0; j < k; j++) {
                rt += ciOptimal[j] * cis[j][i];
            }
            eis[i] = (elements[i] - rt) / diOptimal;
        }
    }

    private static void updateCis(int k, int itemIdNum, float[][] cis, float[] eis) {
        if (itemIdNum >= 0) System.arraycopy(eis, 0, cis[k], 0, itemIdNum);
    }

    private static void updateDi2s(int itemIdNum, float[] di2s, float[] eis) {
        for (int i = 0; i < itemIdNum; i++) {
            di2s[i] -= eis[i] * eis[i];
        }
    }
}
