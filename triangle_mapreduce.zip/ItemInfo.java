package com.alibaba.aliyun.mapred.graph.triangle2.triangle;

public class ItemInfo implements Comparable<ItemInfo> {

    public ItemInfo() {
    }
    public ItemInfo(Long item_id, Long seller_seq, Long pcate_leaf_id,Long cate_lv2_id,Long brand_value_id) {
        this.item_id = item_id;
        this.seller_seq = seller_seq;
        this.pcate_leaf_id = pcate_leaf_id;
        this.cate_lv2_id = cate_lv2_id;
        this.brand_value_id = brand_value_id;
    }
    Long item_id;
    Long seller_seq;
    Long pcate_leaf_id;
    Long cate_lv2_id;
    Long brand_value_id;

    @Override
    public int compareTo(ItemInfo o) {
        return this.item_id.compareTo(o.item_id);
    }

    public int hashCode() {
        return item_id.intValue();
    }

    public  boolean equals(Object object) {
        if (!(object instanceof ItemInfo)) {
           return false;
        }
        ItemInfo o = (ItemInfo) object;
        return o.item_id.equals(this.item_id);
    }
}
