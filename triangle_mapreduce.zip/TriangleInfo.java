package com.alibaba.aliyun.mapred.graph.triangle2.triangle;

public class TriangleInfo implements Comparable<TriangleInfo> {
    public TriangleInfo() {
    }
    public TriangleInfo(Long node_a, Long node_b,Long node_c,Long edge_a_b,Long edge_a_c) {
        this.node_a=node_a;
        this.node_b=node_b;
        this.node_c=node_c;
        this.edge_a_c=edge_a_c;
        this.edge_a_b=edge_a_b;
    }
    public TriangleInfo(Long node_a, Long node_b,Long node_c,Long edge_a_b,Long edge_a_c,Long edge_b_c) {
        this.node_a=node_a;
        this.node_b=node_b;
        this.node_c=node_c;
        this.edge_a_c=edge_a_c;
        this.edge_a_b=edge_a_b;
        this.edge_b_c=edge_b_c;
        this.inner_weight = edge_a_b + edge_a_c + edge_b_c;

    }

    public TriangleInfo(Long node_a, Long node_b,Long node_c,Long edge_a_b,Long edge_a_c,Long edge_b_c,Long center_node) {
        this.node_a=node_a;
        this.node_b=node_b;
        this.node_c=node_c;
        this.edge_a_c=edge_a_c;
        this.edge_a_b=edge_a_b;
        this.edge_b_c=edge_b_c;
        this.center_node = center_node;
        this.link_weight = 0L;
    }

    public TriangleInfo(Long node_a, Long node_b,Long node_c,Long edge_a_b,Long edge_a_c,Long edge_b_c,Long center_node,Long link_weight) {
        this.node_a=node_a;
        this.node_b=node_b;
        this.node_c=node_c;
        this.edge_a_c=edge_a_c;
        this.edge_a_b=edge_a_b;
        this.edge_b_c=edge_b_c;
        this.center_node = center_node;
        this.link_weight = 0L;
        this.inner_weight = edge_a_b + edge_a_c + edge_b_c;
        this.distance_a = 2L;
        this.distance_b = 2L;
        this.distance_c = 2L;
    }

    public TriangleInfo(Long node_a, Long node_b,Long node_c,Long edge_a_b,Long edge_a_c,Long edge_b_c,Long center_node,Long link_weight,String node_a_kw,String node_b_kw,String node_c_kw) {
        this.node_a=node_a;
        this.node_b=node_b;
        this.node_c=node_c;
        this.edge_a_c=edge_a_c;
        this.edge_a_b=edge_a_b;
        this.edge_b_c=edge_b_c;
        this.center_node = center_node;
        this.link_weight = 0L;
        this.inner_weight = edge_a_b + edge_a_c + edge_b_c;
        this.distance_a = 2L;
        this.distance_b = 2L;
        this.distance_c = 2L;
        this.node_a_kw = node_a_kw;
        this.node_b_kw = node_b_kw;
        this.node_c_kw = node_c_kw;
    }

    public TriangleInfo(String node_a, String node_b,String node_c,Double score) {
        this.node_a_str=node_a;
        this.node_b_str=node_b;
        this.node_c_str=node_c;
        this.tri_score = score;
    }

    Long node_a;
    Long node_b;
    Long node_c;
    Long edge_a_b;
    Long edge_a_c;
    Long edge_b_c;
    Long center_node;
    Long link_weight;
    Long inner_weight;
    Long distance_a;
    Long distance_b;
    Long distance_c;
    Double outter_weight;
    Double final_weight;
    String node_a_str;
    String node_b_str;
    String node_c_str;
    Double tri_score;
    String node_a_kw;
    String node_b_kw;
    String node_c_kw;

    public void setEdge_b_c(Long edge_b_c) {
        this.edge_b_c = edge_b_c;
    }

    @Override
    public int compareTo(TriangleInfo o) {
        return o.node_a.compareTo(this.node_a);
    }

    public int hashCode()
    {
        return (node_a.intValue()+node_b.intValue()+node_c.intValue());
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof TriangleInfo)) {
            return false;
        }
        TriangleInfo o = (TriangleInfo) obj;
        if (node_a.equals(o.node_a) && node_b.equals(o.node_b) && node_c.equals(o.node_c)) {
            return true;
        }
        return false;
    }
}
