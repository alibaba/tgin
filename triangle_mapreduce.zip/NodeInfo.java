package com.alibaba.aliyun.mapred.graph.triangle2.triangle;

public class NodeInfo implements Comparable<NodeInfo> {

    public NodeInfo() {
    }
    public NodeInfo(Long node1,Long node2, Long weight) {
        this.node1=node1;
        this.node2=node2;
        this.weight=weight;
    }
    Long node1;
    Long node2;
    public Long weight;
    public Long getNode1() {
        return this.node1;
    }
    public Long getNode2() {
        return this.node2;
    }

    @Override
    public int compareTo(NodeInfo o) {
        return this.node2.compareTo(o.node2);
    }
}
