package com.alibaba.aliyun.mapred.graph.triangle2.triangle;

import com.alibaba.aliyun.mapred.utils.MRUtil;
import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.JobClient;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.RunningJob;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;

import java.io.IOException;
import java.util.*;

/**
 * author lianghuike
 * desc
 */
public class GenTriangleStep5DppLinkWeight {
    static final String MULTI_VALUE_SEPERATOR = "\u001D";

    public static class GenTriangleStep4Mapper extends MapperBase {

        @Override
        public void setup(TaskContext context) throws IOException {
        }

        @Override
        public void map(long recordNum, Record record, TaskContext context)
            throws IOException {

            String currTable = context.getInputTableInfo().getTableName();
            if (currTable.contains("jws_amazon_all_item_undirected_graph_hop0_di")) {
                Long node_a = record.getBigint("node_a");
                Long node_b = record.getBigint("node_b");
                Long node_c = record.getBigint("node_c");

                Long edge_a_b = record.getBigint("edge_a_b");
                Long edge_a_c = record.getBigint("edge_a_c");
                Long edge_b_c = record.getBigint("edge_b_c");

                String node_a_kws = record.getString("node_a_keywords");
                String node_b_kws = record.getString("node_b_keywords");
                String node_c_kws = record.getString("node_c_keywords");

                Record key = context.createMapOutputKeyRecord();
                Record mapValue = context.createMapOutputValueRecord();
                mapValue.setBigint("node_a", node_a);
                mapValue.setBigint("node_b", node_b);
                mapValue.setBigint("node_c", node_c);
                mapValue.setBigint("edge_a_c", edge_a_c);
                mapValue.setBigint("edge_a_b", edge_a_b);
                mapValue.setBigint("edge_b_c",edge_b_c);
                mapValue.setString("node_a_kws", node_a_kws);
                mapValue.setString("node_b_kws", node_b_kws);
                mapValue.setString("node_c_kws", node_c_kws);

                key.setBigint("node_k", node_a);
                mapValue.setString("type","abc_a");
                context.write(key, mapValue);

                key.setBigint("node_k", node_b);
                mapValue.setString("type","abc_b");
                context.write(key, mapValue);

                key.setBigint("node_k", node_c);
                mapValue.setString("type","abc_c");
                context.write(key, mapValue);
            }else if (currTable.contains("all_item_undirected_graph_tmp2_di_two_hop")){
                Long node1 = record.getBigint("node_a");
                Long node2 = record.getBigint("node_b");
                Long weight = record.getBigint("edge_a_b");

                Record key = context.createMapOutputKeyRecord();
                Record mapValue = context.createMapOutputValueRecord();
                key.setBigint("node_k", node1);
                mapValue.setBigint("node_neighbour", node2);
                mapValue.setBigint("weight", weight);
                mapValue.setString("type","neighbour_hop2");
                context.write(key, mapValue);

                key.setBigint("node_k", node2);
                mapValue.setBigint("node_neighbour", node1);
                mapValue.setBigint("weight", weight);
                mapValue.setString("type","neighbour_hop2");
                context.write(key, mapValue);
            }else if (currTable.contains("all_item_undirected_graph_tmp2_di")){
                Long node1 = record.getBigint("node_a");
                Long node2 = record.getBigint("node_b");
                Long weight = record.getBigint("edge_a_b");

                Record key = context.createMapOutputKeyRecord();
                Record mapValue = context.createMapOutputValueRecord();
                key.setBigint("node_k", node1);
                mapValue.setBigint("node_neighbour", node2);
                mapValue.setBigint("weight", weight);
                mapValue.setString("type","neighbour_hop1");
                context.write(key, mapValue);

                key.setBigint("node_k", node2);
                mapValue.setBigint("node_neighbour", node1);
                mapValue.setBigint("weight", weight);
                mapValue.setString("type","neighbour_hop1");
                context.write(key, mapValue);
            }else if (currTable.contains("jws_amazon_all_item_undirected_graph_hop2_di")){
                Long center_node = record.getBigint("center_node");
                Long link_weight = record.getBigint("link_weight");
                Long node_a = record.getBigint("node_a");
                Long node_b = record.getBigint("node_b");
                Long node_c = record.getBigint("node_c");

                Long edge_a_b = record.getBigint("edge_a_b");
                Long edge_a_c = record.getBigint("edge_a_c");
                Long edge_b_c = record.getBigint("edge_b_c");

                String node_a_kws = record.getString("node_a_keywords");
                String node_b_kws = record.getString("node_b_keywords");
                String node_c_kws = record.getString("node_c_keywords");

                Record key = context.createMapOutputKeyRecord();
                Record mapValue = context.createMapOutputValueRecord();
                key.setBigint("node_k", center_node);
                mapValue.setBigint("node_a", node_a);
                mapValue.setBigint("node_b", node_b);
                mapValue.setBigint("node_c", node_c);
                mapValue.setBigint("edge_a_c", edge_a_c);
                mapValue.setBigint("edge_a_b", edge_a_b);
                mapValue.setBigint("edge_b_c",edge_b_c);
                mapValue.setBigint("link_weight",link_weight);
                mapValue.setString("node_a_kws", node_a_kws);
                mapValue.setString("node_b_kws", node_b_kws);
                mapValue.setString("node_c_kws", node_c_kws);

                mapValue.setString("type","link_hop2");
                context.write(key, mapValue);

            }else if (currTable.contains("jws_amazon_all_item_undirected_graph_hop1_di")){
                Long center_node = record.getBigint("center_node");
                Long link_weight = record.getBigint("link_weight");
                Long node_a = record.getBigint("node_a");
                Long node_b = record.getBigint("node_b");
                Long node_c = record.getBigint("node_c");

                Long edge_a_b = record.getBigint("edge_a_b");
                Long edge_a_c = record.getBigint("edge_a_c");
                Long edge_b_c = record.getBigint("edge_b_c");

                String node_a_kws = record.getString("node_a_keywords");
                String node_b_kws = record.getString("node_b_keywords");
                String node_c_kws = record.getString("node_c_keywords");

                Record key = context.createMapOutputKeyRecord();
                Record mapValue = context.createMapOutputValueRecord();
                key.setBigint("node_k", center_node);
                mapValue.setBigint("node_a", node_a);
                mapValue.setBigint("node_b", node_b);
                mapValue.setBigint("node_c", node_c);
                mapValue.setBigint("edge_a_c", edge_a_c);
                mapValue.setBigint("edge_a_b", edge_a_b);
                mapValue.setBigint("edge_b_c",edge_b_c);
                mapValue.setBigint("link_weight",link_weight);
                mapValue.setString("node_a_kws", node_a_kws);
                mapValue.setString("node_b_kws", node_b_kws);
                mapValue.setString("node_c_kws", node_c_kws);

                mapValue.setString("type","link_hop1");
                context.write(key, mapValue);

            }
        }
        @Override
        public void cleanup(TaskContext context) throws IOException {
        }

    }

    public static class GenTriangleStep5Reducer extends ReducerBase {

        private int triangle_num_limit;
        private Double alpha;
        private Double theta;
        private Integer poolSize;

        @Override
        public void setup(TaskContext context) throws IOException {
            triangle_num_limit = Integer.parseInt(context.getJobConf().get("triangle.num.limit"));
            alpha = Double.valueOf(context.getJobConf().get("triangle.alpha"));
            theta = Double.valueOf(context.getJobConf().get("triangle.dpp.theta"));
            poolSize = Integer.valueOf(context.getJobConf().get("triangle.dpp.pool.size"));
        }

        private String genNodeInfo(Long item_id,Long distance) {
            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.append("item_id_");
            stringBuilder.append(item_id);
            stringBuilder.append(MULTI_VALUE_SEPERATOR);
            stringBuilder.append("distance_");
            stringBuilder.append(distance);
            return  stringBuilder.toString();
        }

        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context)
                throws IOException {

            HashMap<Long,Long> edges = new HashMap<>();
            HashMap<Long,Long> edges_hop2 = new HashMap<>();

            Record result = context.createOutputRecord();
            Long node_k = key.getBigint("node_k");
            HashSet<TriangleInfo> l2triangles = new HashSet<>();
            HashSet<TriangleInfo> l1triangles = new HashSet<>();
            HashSet<TriangleInfo> l0triangles = new HashSet<>();

            while (values.hasNext()) {
                Record record = values.next();
                String type = record.getString("type");
                if (type.contains("abc")) {
                    Long node_a = record.getBigint("node_a");
                    Long node_b = record.getBigint("node_b");
                    Long node_c = record.getBigint("node_c");
                    Long edge_a_c = record.getBigint("edge_a_c");
                    Long edge_a_b = record.getBigint("edge_a_b");
                    Long edge_b_c = record.getBigint("edge_b_c");
                    String node_a_kws = record.getString("node_a_kws");
                    String node_b_kws = record.getString("node_b_kws");
                    String node_c_kws = record.getString("node_c_kws");
                    l0triangles.add(new TriangleInfo(node_a,node_b,node_c,edge_a_b,edge_a_c,edge_b_c,key.getBigint("node_k"), 0L, node_a_kws, node_b_kws, node_c_kws));
                }else if (type.contains("neighbour_hop1")){
                    Long node_neighbour = record.getBigint("node_neighbour");
                    Long weight = record.getBigint("weight");
                    edges.put(node_neighbour,weight);
                }else if (type.contains("neighbour_hop2")){
                    Long node_neighbour = record.getBigint("node_neighbour");
                    Long weight = record.getBigint("weight");
                    edges_hop2.put(node_neighbour,weight);
                }else if (type.contains("link_hop1")){
                    Long link_weight = record.getBigint("link_weight");
                    Long node_a = record.getBigint("node_a");
                    Long node_b = record.getBigint("node_b");
                    Long node_c = record.getBigint("node_c");
                    Long edge_a_c = record.getBigint("edge_a_c");
                    Long edge_a_b = record.getBigint("edge_a_b");
                    Long edge_b_c = record.getBigint("edge_b_c");
                    String node_a_kws = record.getString("node_a_kws");
                    String node_b_kws = record.getString("node_b_kws");
                    String node_c_kws = record.getString("node_c_kws");
                    l1triangles.add(new TriangleInfo(node_a,node_b,node_c,edge_a_b,edge_a_c,edge_b_c,key.getBigint("node_k"), 0L, node_a_kws, node_b_kws, node_c_kws));
                }else if (type.contains("link_hop2")){
                    Long link_weight = record.getBigint("link_weight");
                    Long node_a = record.getBigint("node_a");
                    Long node_b = record.getBigint("node_b");
                    Long node_c = record.getBigint("node_c");
                    Long edge_a_c = record.getBigint("edge_a_c");
                    Long edge_a_b = record.getBigint("edge_a_b");
                    Long edge_b_c = record.getBigint("edge_b_c");
                    String node_a_kws = record.getString("node_a_kws");
                    String node_b_kws = record.getString("node_b_kws");
                    String node_c_kws = record.getString("node_c_kws");
                    l2triangles.add(new TriangleInfo(node_a,node_b,node_c,edge_a_b,edge_a_c,edge_b_c,key.getBigint("node_k"), 0L, node_a_kws, node_b_kws, node_c_kws));
                }
            }
            if (l0triangles.size() == 0 && l1triangles.size() == 0 && l2triangles.size() == 0) {
                return;
            }

            double l0sum = 0.0;
            double l1sum = 0.0;
            double l2sum = 0.0;
            for(TriangleInfo t: l0triangles) {
                t.distance_a = 1L;
                t.distance_b = 1L;
                t.distance_c = 1L;
                if (node_k.equals(t.node_a)) {
                    t.distance_a = 0L;
                }else if (node_k.equals(t.node_b)) {
                    t.distance_b = 0L;
                }else if (node_k.equals(t.node_c)) {
                    t.distance_c = 0L;
                }
                t.outter_weight = 1/(t.distance_a.doubleValue() + t.distance_b.doubleValue() + t.distance_c.doubleValue());
                t.final_weight = Math.pow(t.inner_weight.doubleValue(),alpha) * Math.pow(t.outter_weight,(1-alpha));
                l0sum += t.final_weight;
            }
            for(TriangleInfo t: l1triangles) {
                t.distance_a = 2L;
                t.distance_b = 2L;
                t.distance_c = 2L;
                if (edges.containsKey(t.node_a)) {
                    t.distance_a = 1L;
                    t.link_weight += edges.get(t.node_a);
                }else if (edges.containsKey(t.node_b)) {
                    t.distance_b = 1L;
                    t.link_weight += edges.get(t.node_b);
                }else if (edges.containsKey(t.node_c)) {
                    t.distance_c = 1L;
                    t.link_weight += edges.get(t.node_c);
                }
                t.outter_weight = t.link_weight/(t.distance_a.doubleValue() + t.distance_b.doubleValue() + t.distance_c.doubleValue());
                t.final_weight = Math.pow(t.inner_weight.doubleValue(),alpha) * Math.pow(t.outter_weight,(1-alpha));
                l1sum += t.final_weight;
            }
            for(TriangleInfo t: l2triangles) {
                t.distance_a = 3L;
                t.distance_b = 3L;
                t.distance_c = 3L;
                if (edges_hop2.containsKey(t.node_a)) {
                    t.distance_a = 2L;
                    t.link_weight += edges_hop2.get(t.node_a);
                }else if (edges_hop2.containsKey(t.node_b)) {
                    t.distance_b = 2L;
                    t.link_weight += edges_hop2.get(t.node_b);
                }else if (edges_hop2.containsKey(t.node_c)) {
                    t.distance_c = 2L;
                    t.link_weight += edges_hop2.get(t.node_c);
                }
                t.outter_weight = t.link_weight/(t.distance_a.doubleValue() + t.distance_b.doubleValue() + t.distance_c.doubleValue());
                t.final_weight = Math.pow(t.inner_weight.doubleValue(),alpha) * Math.pow(t.outter_weight,(1-alpha));
                l2sum += t.final_weight;
            }

            List<TriangleInfo> l0triangles_list = new ArrayList<>();
            List<TriangleInfo> l1triangles_list = new ArrayList<>();
            List<TriangleInfo> l2triangles_list = new ArrayList<>();
            l0triangles_list.addAll(l0triangles);
            l1triangles_list.addAll(l1triangles);
            l2triangles_list.addAll(l2triangles);
            Collections.sort(l0triangles_list, new Comparator<TriangleInfo>() {
                @Override
                public int compare(TriangleInfo o1, TriangleInfo o2) {
                    return o2.final_weight.compareTo(o1.final_weight);
                }
            });
            Collections.sort(l1triangles_list, new Comparator<TriangleInfo>() {
                @Override
                public int compare(TriangleInfo o1, TriangleInfo o2) {
                    return o2.final_weight.compareTo(o1.final_weight);
                }
            });
            Collections.sort(l2triangles_list, new Comparator<TriangleInfo>() {
                @Override
                public int compare(TriangleInfo o1, TriangleInfo o2) {
                    return o2.final_weight.compareTo(o1.final_weight);
                }
            });

            // 截断1000个应用DPP算法
            int maxNum = poolSize;
            int idx = 0;

            if (l0triangles_list.size() > 0) {
                float[] scoresL0 = new float[maxNum];
                String[] spuIdsL0 = new String[maxNum];
                List<Set<String>> featureMatrixL0 = new ArrayList<>();
                for (int i = 0; i < l0triangles_list.size(); i++) {
                    if (i >= maxNum) {
                        break;
                    }
                    TriangleInfo t = l0triangles_list.get(i);
                    scoresL0[i] = (float) Math.exp((theta / (2 * (1.0 - theta))) * t.final_weight.floatValue());
                    spuIdsL0[i] = String.valueOf(i);
                    String[] tmp = (t.node_a_kw + "," + t.node_b_kw + "," + t.node_c_kw).split(",");
                    featureMatrixL0.add(new HashSet<>(Arrays.asList(tmp)));
                }
                List<String> selectedIdsL0 = Arrays.asList(Dpp.run(triangle_num_limit, spuIdsL0, scoresL0, featureMatrixL0));
                for (int i = 0; i < l0triangles_list.size(); i++) {
                    if (idx >= triangle_num_limit) {
                        break;
                    }
                    if (i >= maxNum) {
                        break;
                    }
                    if (!selectedIdsL0.contains(String.valueOf(i))) {
                        continue;
                    }
                    TriangleInfo t = l0triangles_list.get(i);
                    result.setString("l0_seq_" + idx + "_node_a", genNodeInfo(t.node_a, t.distance_a));
                    result.setString("l0_seq_" + idx + "_node_b", genNodeInfo(t.node_b, t.distance_b));
                    result.setString("l0_seq_" + idx + "_node_c", genNodeInfo(t.node_c, t.distance_c));
                    result.setDouble("l0_seq_" + idx + "_tr_score", t.final_weight);
                    idx++;
                }
            }

            if (l1triangles_list.size() > 0) {
                float[] scoresL1 = new float[maxNum];
                String[] spuIdsL1 = new String[maxNum];
                List<Set<String>> featureMatrixL1 = new ArrayList<>();
                for (int i = 0; i < l1triangles_list.size(); i++) {
                    if (i >= maxNum) {
                        break;
                    }
                    TriangleInfo t = l1triangles_list.get(i);
                    scoresL1[i] = (float) Math.exp((theta / (2 * (1.0 - theta))) * t.final_weight.floatValue());
                    spuIdsL1[i] = String.valueOf(i);
                    String[] tmp = (t.node_a_kw + "," + t.node_b_kw + "," + t.node_c_kw).split(",");
                    featureMatrixL1.add(new HashSet<>(Arrays.asList(tmp)));
                }
                List<String> selectedIdsL1 = Arrays.asList(Dpp.run(triangle_num_limit, spuIdsL1, scoresL1, featureMatrixL1));
                idx = 0;
                for (int i = 0; i < l1triangles_list.size(); i++) {
                    if (idx >= triangle_num_limit) {
                        break;
                    }
                    if (i >= maxNum) {
                        break;
                    }
                    if (!selectedIdsL1.contains(String.valueOf(i))) {
                        continue;
                    }
                    TriangleInfo t = l1triangles_list.get(i);
                    result.setString("l1_seq_" + idx + "_node_a", genNodeInfo(t.node_a, t.distance_a));
                    result.setString("l1_seq_" + idx + "_node_b", genNodeInfo(t.node_b, t.distance_b));
                    result.setString("l1_seq_" + idx + "_node_c", genNodeInfo(t.node_c, t.distance_c));
                    result.setDouble("l1_seq_" + idx + "_tr_score", t.final_weight);
                    result.setBigint("l1_seq_" + idx + "_link_weight", t.link_weight);
                    idx++;
                }
            }

            if (l2triangles_list.size() > 0) {
                float[] scoresL2 = new float[maxNum];
                String[] spuIdsL2 = new String[maxNum];
                List<Set<String>> featureMatrixL2 = new ArrayList<>();
                for (int i = 0; i < l2triangles_list.size(); i++) {
                    if (i >= maxNum) {
                        break;
                    }
                    TriangleInfo t = l2triangles_list.get(i);
                    scoresL2[i] = (float) Math.exp((theta / (2 * (1.0 - theta))) * t.final_weight.floatValue());
                    spuIdsL2[i] = String.valueOf(i);
                    String[] tmp = (t.node_a_kw + "," + t.node_b_kw + "," + t.node_c_kw).split(",");
                    featureMatrixL2.add(new HashSet<>(Arrays.asList(tmp)));
                }
                List<String> selectedIdsL2 = Arrays.asList(Dpp.run(triangle_num_limit, spuIdsL2, scoresL2, featureMatrixL2));
                idx = 0;
                for (int i = 0; i < l2triangles_list.size(); i++) {
                    if (idx >= triangle_num_limit) {
                        break;
                    }
                    if (i >= maxNum) {
                        break;
                    }
                    if (!selectedIdsL2.contains(String.valueOf(i))) {
                        continue;
                    }
                    TriangleInfo t = l2triangles_list.get(i);
                    result.setString("l2_seq_" + idx + "_node_a", genNodeInfo(t.node_a, t.distance_a));
                    result.setString("l2_seq_" + idx + "_node_b", genNodeInfo(t.node_b, t.distance_b));
                    result.setString("l2_seq_" + idx + "_node_c", genNodeInfo(t.node_c, t.distance_c));
                    result.setDouble("l2_seq_" + idx + "_tr_score", t.final_weight);
                    result.setBigint("l2_seq_" + idx + "_link_weight", t.link_weight);
                    idx++;
                }
            }

//            int idx = 0;
//            for(TriangleInfo t: l0triangles_list) {
//                if (idx >= triangle_num_limit) {
//                    break;
//                }
//                result.setString("l0_seq_"+idx+"_node_a", genNodeInfo(t.node_a,t.distance_a));
//                result.setString("l0_seq_"+idx+"_node_b", genNodeInfo(t.node_b,t.distance_b));
//                result.setString("l0_seq_"+idx+"_node_c", genNodeInfo(t.node_c,t.distance_c));
//                result.setDouble("l0_seq_"+idx+"_tr_score", t.final_weight);
//                idx++;
//            }
//
//            idx = 0;
//            for(TriangleInfo t: l1triangles_list) {
//                if (idx >= triangle_num_limit) {
//                    break;
//                }
//                result.setString("l1_seq_"+idx+"_node_a", genNodeInfo(t.node_a,t.distance_a));
//                result.setString("l1_seq_"+idx+"_node_b", genNodeInfo(t.node_b,t.distance_b));
//                result.setString("l1_seq_"+idx+"_node_c", genNodeInfo(t.node_c,t.distance_c));
//                result.setDouble("l1_seq_"+idx+"_tr_score", t.final_weight);
//                result.setBigint("l1_seq_"+idx+"_link_weight", t.link_weight);
//                idx++;
//            }
//
//            idx = 0;
//            for(TriangleInfo t: l2triangles_list) {
//                if (idx >= triangle_num_limit) {
//                    break;
//                }
//                result.setString("l2_seq_"+idx+"_node_a", genNodeInfo(t.node_a,t.distance_a));
//                result.setString("l2_seq_"+idx+"_node_b", genNodeInfo(t.node_b,t.distance_b));
//                result.setString("l2_seq_"+idx+"_node_c", genNodeInfo(t.node_c,t.distance_c));
//                result.setDouble("l2_seq_"+idx+"_tr_score", t.final_weight);
//                result.setBigint("l2_seq_"+idx+"_link_weight", t.link_weight);
//                idx++;
//            }

            result.setBigint("center_node",node_k);
            context.write(result);

        }
    }
            /**
             * Check paramter boolean.
             *
             * @param conf the conf
             * @return the boolean
             * @throws IOException the io exception
             */
    protected boolean checkParamter(JobConf conf) throws IOException {
        MRUtil.auxCheckParamter(conf, "ares.user", true);
        MRUtil.auxCheckParamter(conf, "mapred.job.name", true);
        MRUtil.auxCheckParamter(conf, "mapred.input.tables", true);
        MRUtil.auxCheckParamter(conf, "mapred.output.tables", true);
        return true;
    }

    /**
     * Run int.
     *
     * @param args_in the args in
     * @return the int
     * @throws IOException the io exception
     */
    public int run(String[] args_in) throws IOException, OdpsException {
        JobConf job = new JobConf();
        MRUtil.cmdJobConf(job, args_in);
        if (checkParamter(job) == false) {
            return 1;
        }
        job.setMapperClass(GenTriangleStep5DppLinkWeight.GenTriangleStep4Mapper.class);
        job.setReducerClass(GenTriangleStep5Reducer.class);
        job.setMapOutputKeySchema(SchemaUtils.fromString("node_k:bigint"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("node_a_kws:string,node_b_kws:string,node_c_kws:string,node_center_brand_value_id:bigint,node_center_cate_lv2_id:bigint,node_center_pcate_leaf_id:bigint,node_center_seller_seq:bigint,node_c_brand_value_id:bigint,node_c_cate_lv2_id:bigint,node_c_pcate_leaf_id:bigint,node_c_seller_seq:bigint,node_b_brand_value_id:bigint,node_b_cate_lv2_id:bigint,node_b_pcate_leaf_id:bigint,node_b_seller_seq:bigint,node_a_brand_value_id:bigint,node_a_cate_lv2_id:bigint,node_a_pcate_leaf_id:bigint,node_a_seller_seq:bigint,link_weight:bigint,subject:string,brand_value_id:bigint,cate_lv2_id:bigint,pcate_leaf_id:bigint,seller_seq:bigint,weight:bigint,node_neighbour:bigint,node_k:bigint,node_a:bigint,node_b:bigint,node_c:bigint,edge_a_b:bigint,edge_a_c:bigint,edge_b_c:bigint,type:string"));
        //解析用户的输入表字符串
        MRUtil.addInputTables(job,job.get("mapred.input.tables"));
        //解析用户的输出表字符串
        MRUtil.addOutputTables(job,job.get("mapred.output.tables"));
        //HdfsUtil.delMROutputPath(conf);
        RunningJob rj = JobClient.runJob(job);
        if (!rj.isSuccessful()) {
            return -1;
        }
        return 0;
    }

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     * @throws IOException the io exception
     */
    public static void main(String[] args) throws IOException, OdpsException {


        GenTriangleStep5DppLinkWeight runner = new GenTriangleStep5DppLinkWeight();
        int n = -1;
        n = runner.run(args);

        System.out.println(n);
        if (n != 0) {
            System.out.println("error!");
            System.exit(-1);
        } else if (n == 0) {
            System.out.println("succeed!");
            System.exit(0);
        }
    }
}
