package com.alibaba.aliyun.mapred.graph.triangle2.triangle;

import com.alibaba.aliyun.mapred.utils.MRUtil;
import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.JobClient;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.RunningJob;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;

import java.io.IOException;
import java.util.*;

/**
 * author lianghuike
 * desc
 */
public class GenTriangleStep4 {
    public static class GenTriangleStep4Mapper extends MapperBase {

        @Override
        public void setup(TaskContext context) throws IOException {
        }

        @Override
        public void map(long recordNum, Record record, TaskContext context)
            throws IOException {

            String currTable = context.getInputTableInfo().getTableName();
            if (currTable.contains("all_item_undirected_graph_base_di")) {
                Long node_a = record.getBigint("node_a");
                Long node_b = record.getBigint("node_b");
                Long node_c = record.getBigint("node_c");

                Long edge_a_b = record.getBigint("edge_a_b");
                Long edge_a_c = record.getBigint("edge_a_c");
                Long edge_b_c = record.getBigint("edge_b_c");

                Record key = context.createMapOutputKeyRecord();
                Record mapValue = context.createMapOutputValueRecord();
                key.setBigint("node_k", node_a);
                mapValue.setBigint("node_a", node_a);
                mapValue.setBigint("node_b", node_b);
                mapValue.setBigint("node_c", node_c);
                mapValue.setBigint("edge_a_c", edge_a_c);
                mapValue.setBigint("edge_a_b", edge_a_b);
                mapValue.setBigint("edge_b_c",edge_b_c);
                mapValue.setString("type","abc_a");
                context.write(key, mapValue);

                key.setBigint("node_k", node_b);
                mapValue.setBigint("node_a", node_a);
                mapValue.setBigint("node_b", node_b);
                mapValue.setBigint("node_c", node_c);
                mapValue.setBigint("edge_a_c", edge_a_c);
                mapValue.setBigint("edge_a_b", edge_a_b);
                mapValue.setBigint("edge_b_c",edge_b_c);
                mapValue.setString("type","abc_b");
                context.write(key, mapValue);

                key.setBigint("node_k", node_c);
                mapValue.setBigint("node_a", node_a);
                mapValue.setBigint("node_b", node_b);
                mapValue.setBigint("node_c", node_c);
                mapValue.setBigint("edge_a_c", edge_a_c);
                mapValue.setBigint("edge_a_b", edge_a_b);
                mapValue.setBigint("edge_b_c",edge_b_c);
                mapValue.setString("type","abc_c");
                context.write(key, mapValue);

            }else if (currTable.contains("all_item_undirected_graph_tmp2_di")){
                Long node1 = record.getBigint("node_a");
                Long node2 = record.getBigint("node_b");
                Long weight = record.getBigint("edge_a_b");


                Record key = context.createMapOutputKeyRecord();
                Record mapValue = context.createMapOutputValueRecord();
                key.setBigint("node_k", node1);
                mapValue.setBigint("node_neighbour", node2);
                mapValue.setBigint("weight", weight);
                mapValue.setString("type","neighbour");
                context.write(key, mapValue);

                key.setBigint("node_k", node2);
                mapValue.setBigint("node_neighbour", node1);
                mapValue.setBigint("weight", weight);
                mapValue.setString("type","neighbour");
                context.write(key, mapValue);

            }
        }
        @Override
        public void cleanup(TaskContext context) throws IOException {
        }

    }

    public static class GenTriangleStep4Reducer extends ReducerBase {


        @Override
        public void setup(TaskContext context) throws IOException {
        }


        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context)
                throws IOException {

            List<TriangleInfo> triangleInfos = new ArrayList<>();
            HashMap<Long,Long> edges = new HashMap<>();

            Record result = context.createOutputRecord();

            while (values.hasNext()) {
                Record record = values.next();
                String type = record.getString("type");
                if (type.contains("abc")) {
                    Long node_a = record.getBigint("node_a");
                    Long node_b = record.getBigint("node_b");
                    Long node_c = record.getBigint("node_c");
                    Long edge_a_c = record.getBigint("edge_a_c");
                    Long edge_a_b = record.getBigint("edge_a_b");
                    Long edge_b_c = record.getBigint("edge_b_c");
                    triangleInfos.add(new TriangleInfo(node_a,node_b,node_c,edge_a_b,edge_a_c,edge_b_c,key.getBigint("node_k")));
                }else {
                    Long node_neighbour = record.getBigint("node_neighbour");
                    Long weight = record.getBigint("weight");
                    edges.put(node_neighbour,weight);
                }
            }
            for(Map.Entry<Long,Long> entry:edges.entrySet()) {
                for (TriangleInfo triangleInfo : triangleInfos) {
                    Long node_neighbour = entry.getKey();
                    if (node_neighbour.equals(triangleInfo.node_a) || node_neighbour.equals(triangleInfo.node_b) || node_neighbour.equals(triangleInfo.node_c)) {
                        continue;
                    }
                    result.setBigint("node_a", triangleInfo.node_a);
                    result.setBigint("node_b", triangleInfo.node_b);
                    result.setBigint("node_c", triangleInfo.node_c);
                    result.setBigint("edge_a_b", triangleInfo.edge_a_b);
                    result.setBigint("edge_a_c", triangleInfo.edge_a_c);
                    result.setBigint("edge_b_c", triangleInfo.edge_b_c);
                    result.setBigint("center_node", node_neighbour);
                    result.setBigint("link_weight", entry.getValue());

                    context.write(result);
                }
            }

        }
    }
            /**
             * Check paramter boolean.
             *
             * @param conf the conf
             * @return the boolean
             * @throws IOException the io exception
             */
    protected boolean checkParamter(JobConf conf) throws IOException {
        MRUtil.auxCheckParamter(conf, "ares.user", true);
        MRUtil.auxCheckParamter(conf, "mapred.job.name", true);
        MRUtil.auxCheckParamter(conf, "mapred.input.tables", true);
        MRUtil.auxCheckParamter(conf, "mapred.output.tables", true);
        return true;
    }

    /**
     * Run int.
     *
     * @param args_in the args in
     * @return the int
     * @throws IOException the io exception
     */
    public int run(String[] args_in) throws IOException, OdpsException {
        JobConf job = new JobConf();
        MRUtil.cmdJobConf(job, args_in);
        if (checkParamter(job) == false) {
            return 1;
        }
        job.setMapperClass(GenTriangleStep4.GenTriangleStep4Mapper.class);
        job.setReducerClass(GenTriangleStep4.GenTriangleStep4Reducer.class);
        job.setMapOutputKeySchema(SchemaUtils.fromString("node_k:bigint"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("subject:string,brand_value_id:bigint,cate_lv2_id:bigint,pcate_leaf_id:bigint,seller_seq:bigint,weight:bigint,node_neighbour:bigint,node_k:bigint,node_a:bigint,node_b:bigint,node_c:bigint,edge_a_b:bigint,edge_a_c:bigint,edge_b_c:bigint,type:string"));
        //解析用户的输入表字符串
        MRUtil.addInputTables(job,job.get("mapred.input.tables"));
        //解析用户的输出表字符串
        MRUtil.addOutputTables(job,job.get("mapred.output.tables"));
        //HdfsUtil.delMROutputPath(conf);
        RunningJob rj = JobClient.runJob(job);
        if (!rj.isSuccessful()) {
            return -1;
        }
        return 0;
    }

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     * @throws IOException the io exception
     */
    public static void main(String[] args) throws IOException, OdpsException {


        GenTriangleStep4 runner = new GenTriangleStep4();
        int n = -1;
        n = runner.run(args);

        System.out.println(n);
        if (n != 0) {
            System.out.println("error!");
            System.exit(-1);
        } else if (n == 0) {
            System.out.println("succeed!");
            System.exit(0);
        }
    }
}
