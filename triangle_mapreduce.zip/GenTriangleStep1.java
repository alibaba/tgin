package com.alibaba.aliyun.mapred.graph.triangle2.triangle;

import com.alibaba.aliyun.mapred.utils.MRUtil;
import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.JobClient;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.RunningJob;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;

import java.io.IOException;
import java.util.*;

/**
 * author lianghuike
 * desc
 */
public class GenTriangleStep1 {
    public static class GenTriangleStep3Mapper extends MapperBase {

        private Long edge_weight_limit;
        @Override
        public void setup(TaskContext context) throws IOException {
            edge_weight_limit = Long.valueOf(context.getJobConf().get("edge.weight.limit"));

        }

        @Override
        public void map(long recordNum, Record record, TaskContext context)
            throws IOException {

            Long node1 = record.getBigint("node1");
            Long node2 = record.getBigint("node2");
            Long weight = record.getBigint("weight");
            if (weight <= edge_weight_limit) {
                return;
            }


            Record key = context.createMapOutputKeyRecord();
            key.setBigint("node1",node1);
            Record mapValue = context.createMapOutputValueRecord();
            mapValue.setBigint("node2",node2);
            mapValue.setBigint("weight",weight);
            context.write(key, mapValue);
        }
        @Override
        public void cleanup(TaskContext context) throws IOException {
        }

    }

    public static class GenTriangleStep1Reducer extends ReducerBase {

        private Integer edge_num_limit;

        @Override
        public void setup(TaskContext context) throws IOException {
            edge_num_limit = Integer.valueOf(context.getJobConf().get("edge.num.limit"));
        }


        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context)
                throws IOException {

            List<NodeInfo> nodes = new ArrayList<>();
            Long node1 = key.getBigint("node1");
            Record result = context.createOutputRecord();
            result.setBigint("node_a", node1);

            while (values.hasNext()) {
                Record record = values.next();
                Long node2 = record.getBigint("node2");
                Long weight = record.getBigint("weight");
                nodes.add(new NodeInfo(node1, node2, weight));
            }
            Collections.sort(nodes, new Comparator<NodeInfo>() {
                @Override
                public int compare(NodeInfo o1, NodeInfo o2) {
                    return o2.weight.compareTo(o1.weight);
                }
            });
            for (Integer i = 0; i < nodes.size() && i < edge_num_limit; ++i) {
                NodeInfo node_b = nodes.get(i);
                result.setBigint("node_b", node_b.node2);
                result.setBigint("edge_a_b", node_b.weight);
                context.write(result);
            }

        }
    }
            /**
             * Check paramter boolean.
             *
             * @param conf the conf
             * @return the boolean
             * @throws IOException the io exception
             */
    protected boolean checkParamter(JobConf conf) throws IOException {
        MRUtil.auxCheckParamter(conf, "ares.user", true);
        MRUtil.auxCheckParamter(conf, "mapred.job.name", true);
        MRUtil.auxCheckParamter(conf, "mapred.input.tables", true);
        MRUtil.auxCheckParamter(conf, "mapred.output.tables", true);
        return true;
    }

    /**
     * Run int.
     *
     * @param args_in the args in
     * @return the int
     * @throws IOException the io exception
     */
    public int run(String[] args_in) throws IOException, OdpsException {
        JobConf job = new JobConf();
        MRUtil.cmdJobConf(job, args_in);
        if (checkParamter(job) == false) {
            return 1;
        }
        job.setMapperClass(GenTriangleStep1.GenTriangleStep3Mapper.class);
        job.setReducerClass(GenTriangleStep1Reducer.class);
        job.setMapOutputKeySchema(SchemaUtils.fromString("node1:bigint"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("node2:bigint,weight:bigint"));
        //解析用户的输入表字符串
        MRUtil.addInputTables(job,job.get("mapred.input.tables"));
        //解析用户的输出表字符串
        MRUtil.addOutputTables(job,job.get("mapred.output.tables"));
        //HdfsUtil.delMROutputPath(conf);
        RunningJob rj = JobClient.runJob(job);
        if (!rj.isSuccessful()) {
            return -1;
        }
        return 0;
    }

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     * @throws IOException the io exception
     */
    public static void main(String[] args) throws IOException, OdpsException {


        GenTriangleStep1 runner = new GenTriangleStep1();
        int n = -1;
        n = runner.run(args);

        System.out.println(n);
        if (n != 0) {
            System.out.println("error!");
            System.exit(-1);
        } else if (n == 0) {
            System.out.println("succeed!");
            System.exit(0);
        }
    }
}
